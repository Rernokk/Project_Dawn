﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface KillObjectiveInterface
{
  void AddEnemyToKillList(Monster monster, int count);
}
