﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class CSVReader : MonoBehaviour {
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown(KeyCode.K)){
      Bitmasking_Value tracker = GetComponent<Bitmasking_Value>();
      tracker.IndexLookup = new List<Bitmasking_Value.BitmaskPairValue>();
      StreamReader reader = new StreamReader("Assets/References/PairsReordered.csv");
      for (int i = 0; i < 255; i++){
        string line = reader.ReadLine();
        int myVal = int.Parse(line.Substring(0, line.IndexOf(",")));
        int myIndex = int.Parse(line.Substring(line.IndexOf(",")+1));
        tracker.IndexLookup.Add(new Bitmasking_Value.BitmaskPairValue(myIndex, myVal));
      }
    }
	}
}
