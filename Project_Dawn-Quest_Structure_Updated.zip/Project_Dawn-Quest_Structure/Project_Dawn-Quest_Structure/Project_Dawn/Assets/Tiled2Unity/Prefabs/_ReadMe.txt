Prefabs directory

Tiled2Unity scripts will build prefabs here. These prefabs can be easily placed 
in your Unity scenes. These prefabs are the end products of Tiled2Unity 
exporting.